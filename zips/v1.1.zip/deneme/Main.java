import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class Main extends JPanel {
    public static void main(String[] args) {
        new Main();
    }

    int imageCount;
    public final int SCREEN_WIDTH, SCREEN_HEIGHT;
    public final int ICON_SIZE =200;
    BufferedImage[] images;
    BufferedImage[] imageIcons;
    int selectedX=0,selectedY=0;
    String state = "selection"; // selection or carousel
    int maxX,maxY;
    int currentImage = 0;
    BufferedImage imageToCrop = null;
    BufferedImage iconToCrop = null;

    int cropImX;
    int cropImY;
    int cropIcx;
    int cropIcY;

    int infoX; int infoY;

    char cropMod;
    int cropCount;

    public Main() {

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.SCREEN_WIDTH = (int) screenSize.getWidth();
        this.SCREEN_HEIGHT = (int) screenSize.getHeight() - 70;



        File[] files = findImages();
        imageCount = files.length;
        images = new BufferedImage[imageCount];
        imageIcons = new BufferedImage[imageCount];

        try {
            for (int a = 0; a < imageCount; a++) {
                images[a] = ImageIO.read(files[a]);
                imageIcons[a] = this.toBufferedImage(images[a].getScaledInstance(ICON_SIZE, ICON_SIZE, BufferedImage.SCALE_FAST));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        JFrame mainF = new JFrame();
        mainF.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        mainF.setExtendedState(Frame.MAXIMIZED_BOTH);
        mainF.setSize(500, 700);
        mainF.setLocationRelativeTo(null);
        mainF.add(this);
        mainF.setBackground(Color.DARK_GRAY);
        mainF.addKeyListener(new Keys());
        this.setBackground(Color.DARK_GRAY);


        mainF.setVisible(true);


    }

    public File[] findImages() {
        String directoryPath = "./resources";

        // Regex deseni: .jpg, .jpeg, veya .png uzantılı dosyalar
        Pattern pattern = Pattern.compile(".*\\.(jpg|jpeg|png)$", Pattern.CASE_INSENSITIVE);

        File dir = new File(directoryPath);

        // Dizindeki tüm uygun dosyaları listele
        File[] files = dir.listFiles((dir1, name) -> pattern.matcher(name).matches());

        if (files != null) {
            for (File file : files) {
                System.out.println(file.getName());
            }
        } else {
            System.out.println("Belirtilen dizin geçerli değil veya dizinde hiçbir dosya bulunamadı.");
        }

        return files;
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (state.equals("selection"))
        {
            maxX = SCREEN_WIDTH/ICON_SIZE;
            maxY = SCREEN_HEIGHT/ICON_SIZE;
            for (int y = 0; y < maxY; y++) {
                for (int x = 0; x < maxX && y*maxX+x < imageIcons.length; x++) {
                    g.drawImage(imageIcons[y*maxX+x], x * ICON_SIZE, y*ICON_SIZE, this);
                }
            }
            int boldness = 5;
            g.setColor(Color.RED);
            g.fillRect(selectedX*ICON_SIZE,selectedY*ICON_SIZE,ICON_SIZE,boldness);
            g.fillRect((selectedX+1)*ICON_SIZE,selectedY*ICON_SIZE,boldness,ICON_SIZE+boldness);
            g.fillRect((selectedX)*ICON_SIZE,(selectedY+1)*ICON_SIZE,ICON_SIZE+boldness,boldness);
            g.fillRect((selectedX)*ICON_SIZE,(selectedY)*ICON_SIZE,boldness,ICON_SIZE);

        }
        else {
            g.drawImage(iconToCrop,0,0,this);
            g.setColor(Color.BLACK);
            ArrayList<String> strings = new ArrayList<>();
            strings.add("INSTAGRAM CAROUSEL ARACI");
            strings.add("");
            strings.add("Instagram'a paylaşacağınız fotoyu bölmek istediğiniz parçayı klavyeden yazın.");
            strings.add("bölünecek parça sayısı: " + cropCount);
            strings.add("");
            strings.add("basılı tutarak kırpmak istediğiniz bölgeyi seçin");
            strings.add("yada tıklayarak yapabilirsiniz: ilk tıklama en sol st köşe için, ikinci tıklama en sağ alt köşe için");
            strings.add("memnun olduğunuz takdirde enter'a basınız. aynı dizine yeni fotoğraflar bir klasör içerisinde verilecektir");
            strings.add("");
            strings.add("Q: 1:1 ratio seçer (kare)");
            strings.add("W: 4/% ratio seçer (dikey)");
            strings.add("şuanki mod: " + cropMod);
            strings.add("");
            strings.add("esc'ye basarak yeniden fotoğraf seçebilirsiniz");
            strings.add("Nihat Emre Yüzügüldü github.com/mrnhtyzgld");



            for (int a = 0; a < strings.size(); a++) {
                g.drawString(strings.get(a), infoX,infoY+a*30);
            }


        }

    }

    public static BufferedImage toBufferedImage(Image img) {
        if (img instanceof BufferedImage) {
            return (BufferedImage) img;
        }

        // Create a buffered image with transparency
        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

        // Draw the image on to the buffered image
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img, 0, 0, null);
        bGr.dispose();

        // Return the buffered image
        return bimage;
    }

    class Keys implements KeyListener {

        @Override
        public void keyReleased(KeyEvent e) {
            if (state.equals("selection")) {
                if (e.getKeyCode() == 38) { // w
                    selectedY = Math.max(0, --selectedY);
                }
                if (e.getKeyCode() == 37) { // a
                    selectedX = Math.max(0, --selectedX);
                }
                if (e.getKeyCode() == 40) { // s
                    if (selectedY * maxX + selectedX + maxX < imageCount)
                        selectedY++;
                }
                if (e.getKeyCode() == 39) { // d
                    if (selectedY * maxX + selectedX + 1 < imageCount && selectedX + 1 < maxX)
                        selectedX++;
                }

                if (e.getKeyCode() == 10) { // enter

                    imageToCrop = images[currentImage];
                    state = "carousel";
                    int bufferDistance = 100;
                    int windowBuffer=100;
                    if (SCREEN_WIDTH / imageToCrop.getWidth() >= SCREEN_HEIGHT / imageToCrop.getHeight()) // h
                    {
                        iconToCrop = Main.toBufferedImage(imageToCrop.getScaledInstance(imageToCrop.getWidth() * SCREEN_HEIGHT / imageToCrop.getHeight(), (SCREEN_HEIGHT * imageToCrop.getHeight() / imageToCrop.getHeight()), BufferedImage.SCALE_FAST));
                        infoX =iconToCrop.getWidth()+bufferDistance;
                        infoY = 0+windowBuffer;
                    } else {
                        iconToCrop = Main.toBufferedImage(imageToCrop.getScaledInstance(imageToCrop.getWidth() * SCREEN_HEIGHT / imageToCrop.getWidth(), (SCREEN_HEIGHT * imageToCrop.getHeight() / imageToCrop.getWidth()), BufferedImage.SCALE_FAST));
                        infoX = 0;
                        infoY = iconToCrop.getHeight()+bufferDistance+windowBuffer;
                    }
                    cropImX = imageToCrop.getWidth();
                    cropImY = imageToCrop.getHeight();
                    cropIcx = iconToCrop.getWidth();
                    cropIcY = iconToCrop.getHeight();

                    currentImage = selectedX + selectedY * maxX;
                    repaint();
                    return;
                }
            }
            if (e.getKeyCode() == 27) // esc
            {
                state = "selection";iconToCrop=null;imageToCrop=null;
            }
            if (e.getKeyChar()=='q')
            {
                cropMod='q';
            }
            if (e.getKeyChar()=='w')
            {
                cropMod='w';
            }
            if (e.getKeyChar()>='0' &&e.getKeyChar()<='9') // numbers
            {
                cropCount=e.getKeyChar()-'0';
            }
            repaint();
        }

        @Override
        public void keyTyped(KeyEvent e) {}

        @Override
        public void keyPressed(KeyEvent e) {

        }
    }

}
